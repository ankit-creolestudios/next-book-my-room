import React from "react";
import ResetPasswordForm from "../../../components/user/ResetPasswordForm";

const ResetPassword = () => {
  return <ResetPasswordForm />;
};

export default ResetPassword;
