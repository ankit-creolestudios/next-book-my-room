import React from "react";
import ForgotPasswordForm from "../../components/user/ForgotPasswordForm";

const ForgotPassword = () => {
  return <ForgotPasswordForm />;
};

export default ForgotPassword;
