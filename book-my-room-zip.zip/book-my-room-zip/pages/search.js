import SearchItem from "../components/SearchItem";

export default function Search() {
  return (
    <div>
      <div>
        <SearchItem />
      </div>
    </div>
  );
}
