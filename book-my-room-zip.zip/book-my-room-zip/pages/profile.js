import React from "react";
import ProfileForm from "../components/user/ProfileForm";

const Profile = () => {
  return (
    <div>
      Profile
      <div>
        <ProfileForm />
      </div>
    </div>
  );
};

export default Profile;
