module.exports = {
  env: {
    DB_LOCAL_URI:
      "mongodb+srv://root:root@cluster0.jlttbja.mongodb.net/rooms?retryWrites=true&w=majority",

    MAIL_CLIENT_ID:
      "631907102676-nc753ud14q9t146src9ctpu29dt83pra.apps.googleusercontent.com",
    MAIL_CLIENT_SECRET: "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",
    MAIL_REFRESH_TOKEN:
      "1//04H5wI2Nf09QcCgYIARAAGAQSNwF-L9IrQ4ty28YTN6AHW1DGJESSnY7G75ZWBLBg7KIs-BKWwOu9blGWZslRivt8vRN0A6u9hjM",
    SENDER_EMAIL_ADDRESS: "ankit.kumar@creolestudios.com",
    SENDER_MAIL_PASSWORD: "@Ankitkn1234",
  },
};
