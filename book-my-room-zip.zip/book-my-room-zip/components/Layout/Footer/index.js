import React from "react";

const Footer = () => {
  return (
    <footer className="footer">
      <p className="text-center">Noyo Room , All Rights Reserved</p>
    </footer>
  );
};

export default Footer;
